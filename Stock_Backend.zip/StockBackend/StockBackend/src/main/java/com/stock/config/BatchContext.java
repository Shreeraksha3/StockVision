package com.stock.config;

import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.scope.context.StepSynchronizationManager;
import org.springframework.batch.item.ExecutionContext;
import org.springframework.stereotype.Component;

@Component
public class BatchContext {


    private ExecutionContext executionContext() {
        StepExecution stepExecution =
                StepSynchronizationManager.getContext().getStepExecution();
        return stepExecution.getJobExecution().getExecutionContext();
    }


    public void incrementUpdated() {
        ExecutionContext ctx = executionContext();
        ctx.putInt("updated", ctx.getInt("updated", 0) + 1);
    }

    public void incrementSkipped() {
        ExecutionContext ctx = executionContext();
        ctx.putInt("skipped", ctx.getInt("skipped", 0) + 1);
    }

    public void apiLimitReached() {
        ExecutionContext ctx = executionContext();
        ctx.put("apiLimitReached", Boolean.TRUE);
    }


    public boolean isApiLimitReached() {
        ExecutionContext ctx = executionContext();
        Object value = ctx.get("apiLimitReached");
        return value instanceof Boolean && (Boolean) value;
    }

}