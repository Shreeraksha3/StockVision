package com.stock.job;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

@Component
@EnableScheduling
public class JobScheduler {

    private final JobLauncher jobLauncher;
    private final Job dailyJob;

    public JobScheduler(
            JobLauncher jobLauncher,
            @Qualifier("dailyJob") Job dailyJob) {

        this.jobLauncher = jobLauncher;
        this.dailyJob = dailyJob;
    }

    @Scheduled(cron = "0 30 9 * * ?")
    public void runJob() throws Exception {

        JobParameters params = new JobParametersBuilder()
                .addLong("time", System.currentTimeMillis())
                .toJobParameters();

        jobLauncher.run(dailyJob, params);
    }
}

