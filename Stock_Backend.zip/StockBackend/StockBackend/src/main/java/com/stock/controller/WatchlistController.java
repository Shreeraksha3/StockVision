package com.stock.controller;

import com.stock.dto.StockView;
import com.stock.entity.Stock;
import com.stock.entity.User;
import com.stock.entity.Watchlist;
import com.stock.repository.StockRepository;
import com.stock.repository.UserRepository;
import com.stock.repository.WatchlistRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/watchlist")
@CrossOrigin(origins = "*")
@RequiredArgsConstructor
public class WatchlistController {
    private final WatchlistRepository watchlistRepository;
    private final UserRepository userRepository;
    private final StockRepository stockRepository;

    @PostMapping("/add/{symbol}")
    public ResponseEntity<Map<String,String>> add(@PathVariable String symbol, Authentication auth){
        String username = auth.getName();
        User user = userRepository.findByUsername(username).orElseThrow(() -> new RuntimeException("User not found"));
        Stock stock = stockRepository.findBySymbol(symbol);
        boolean exists = watchlistRepository.existsByUserIdAndStockSymbol(user.getId(),symbol);
        if(exists){
            return ResponseEntity.badRequest().body(Map.of("message", "Stock already in watchlist"));
        }
        Watchlist watchlist = new Watchlist();
        watchlist.setUser(user);
        watchlist.setStock(stock);
        watchlistRepository.save(watchlist);
        return ResponseEntity.ok(Map.of("message", "Stock added to watchlist"));
    }

    @GetMapping
    public List<StockView> get(Authentication auth){
        String username = auth.getName();
        return watchlistRepository.getUserWatchlist(username);
    }

    @DeleteMapping("/remove/{symbol}")
    public ResponseEntity<Map<String,String>> remove(@PathVariable String symbol,Authentication auth){
        String username = auth.getName();
        User user = userRepository.findByUsername(username).orElseThrow(() -> new RuntimeException("User not found"));
        Watchlist watchlist = watchlistRepository.findByUserIdAndStockSymbol(user.getId(), symbol)
                .orElseThrow(() -> new RuntimeException("Stock not in watchlist"));
        watchlistRepository.delete(watchlist);
        return ResponseEntity.ok(Map.of("message", "Stock removed from watchlist"));
    }
}
