package com.stock.dto.wrapper;

import org.springframework.stereotype.Component;

import java.time.DayOfWeek;
import java.time.LocalDate;

@Component
public class TradingDateUtil {

    public LocalDate getLastTradingDay() {
        LocalDate today = LocalDate.now();

        if (today.getDayOfWeek() == DayOfWeek.SUNDAY) return today.minusDays(1);
        if (today.getDayOfWeek() == DayOfWeek.MONDAY) return today.minusDays(2);

        return today;
    }

    public LocalDate getLastFriday() {
        return LocalDate.now().with(DayOfWeek.SUNDAY);
    }

    public LocalDate getLastMonthEnd() {
        LocalDate lastMonth = LocalDate.now().minusMonths(1);
        return lastMonth.withDayOfMonth(lastMonth.lengthOfMonth());
    }
}