package com.stock.service;

import com.stock.entity.Stock;
import com.stock.entity.TimeSeriesData;
import com.stock.repository.TimeSeriesDataRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.Map;

@Service
public class BatchService {

    @Value("${ALPHAVANTAGE_APIKEY}")
    private String apiKey;

    @Value("${ALPHAVANTAGE_BASEURL}")
    private String baseUrl;

    @Autowired
    private RestTemplate restTemplate;

    @Autowired
    private TimeSeriesDataRepository repository;

    public boolean fetchDaily(Stock stock) {
        String symbol = stock.getSymbol();

        //SETTING URL AND CALLING API
        String dailyUrl = baseUrl + "?function=TIME_SERIES_DAILY" + "&symbol=" + symbol + "&apikey=" + apiKey;
        //System.out.println(dailyUrl);
        Map<String, Object> dailyResponse;
        try {
            dailyResponse = restTemplate.getForObject(dailyUrl, Map.class);
            //System.out.println(dailyResponse);

        } catch (Exception e) {
            System.out.println("API CALL FAILED : " + e.getMessage());
            throw new RuntimeException("External API Error");
        }
        if (dailyResponse.containsKey("Note")) {
            throw new RuntimeException("API limit reached: " + dailyResponse.get("Note"));
        }
        if (dailyResponse.containsKey("Information")) {
            throw new RuntimeException("API limit reached: " + dailyResponse.get("Information"));
        }
        if (dailyResponse == null || !dailyResponse.containsKey("Time Series (Daily)")) {
            throw new RuntimeException("Invalid API response");
        }

        Map<String, Map<String, String>> response =
                (Map<String, Map<String, String>>) dailyResponse.get("Time Series (Daily)");

//        List<TimeSeriesData> result = new ArrayList<>();

        //EXTARCTING EACH DATE STOCK VALUES AND STORING IN DB
        for (Map.Entry<String, Map<String, String>> entry : response.entrySet()) {

            LocalDate date = LocalDate.parse(entry.getKey());
            Map<String, String> values = entry.getValue();
            if(repository.findByStockAndDateAndIntervalType(
                    stock, date, "DAILY").isPresent()) {
                continue;
            }
            TimeSeriesData data = new TimeSeriesData();
            data.setStock(stock);
            data.setDate(date);
            data.setOpen(new BigDecimal(values.get("1. open")));
            data.setHigh(new BigDecimal(values.get("2. high")));
            data.setLow(new BigDecimal(values.get("3. low")));
            data.setClose(new BigDecimal(values.get("4. close")));
            data.setVolume(Long.parseLong(values.get("5. volume")));
            data.setIntervalType("DAILY");
            repository.save(data);

            //result.add(data);
        }
        //result.sort(Comparator.comparing(TimeSeriesData::getDate));
        return true;
    }

    public boolean fetchWeekly(Stock stock){
        String symbol = stock.getSymbol();

        //SETTING URL AND CALLING API
        String dailyUrl = baseUrl + "?function=TIME_SERIES_WEEKLY" + "&symbol=" + symbol + "&apikey=" + apiKey;
        //System.out.println(dailyUrl);
        Map<String, Object> dailyResponse;
        try {
            dailyResponse = restTemplate.getForObject(dailyUrl, Map.class);
            //System.out.println(dailyResponse);

        } catch (Exception e) {
            System.out.println("API CALL FAILED : " + e.getMessage());
            throw new RuntimeException("External API Error");
        }
        if (dailyResponse.containsKey("Note")) {
            throw new RuntimeException("API limit reached: " + dailyResponse.get("Note"));
        }
        if (dailyResponse.containsKey("Information")) {
            throw new RuntimeException("API limit reached: " + dailyResponse.get("Information"));
        }
        if (dailyResponse == null || !dailyResponse.containsKey("Weekly Time Series")) {
            throw new RuntimeException("Invalid API response");
        }

        Map<String, Map<String, String>> response =
                (Map<String, Map<String, String>>) dailyResponse.get("Weekly Time Series");

//        List<TimeSeriesData> result = new ArrayList<>();

        //EXTARCTING EACH DATE STOCK VALUES AND STORING IN DB
        for (Map.Entry<String, Map<String, String>> entry : response.entrySet()) {

            LocalDate date = LocalDate.parse(entry.getKey());
            Map<String, String> values = entry.getValue();
            if(repository.findByStockAndDateAndIntervalType(
                    stock, date, "WEEKLY").isPresent()) {
                continue;
            }
            TimeSeriesData data = new TimeSeriesData();
            data.setStock(stock);
            data.setDate(date);
            data.setOpen(new BigDecimal(values.get("1. open")));
            data.setHigh(new BigDecimal(values.get("2. high")));
            data.setLow(new BigDecimal(values.get("3. low")));
            data.setClose(new BigDecimal(values.get("4. close")));
            data.setVolume(Long.parseLong(values.get("5. volume")));
            data.setIntervalType("WEEKLY");
            repository.save(data);

            //result.add(data);
        }
        //result.sort(Comparator.comparing(TimeSeriesData::getDate));
        return true;
    }

    public boolean fetchMonthly(Stock stock){
        String symbol = stock.getSymbol();

        //SETTING URL AND CALLING API
        String dailyUrl = baseUrl + "?function=TIME_SERIES_MONTHLY" + "&symbol=" + symbol + "&apikey=" + apiKey;
        //System.out.println(dailyUrl);
        Map<String, Object> dailyResponse;
        try {
            dailyResponse = restTemplate.getForObject(dailyUrl, Map.class);
            //System.out.println(dailyResponse);

        } catch (Exception e) {
            System.out.println("API CALL FAILED : " + e.getMessage());
            throw new RuntimeException("External API Error");
        }
        if (dailyResponse.containsKey("Note")) {
            throw new RuntimeException("API limit reached: " + dailyResponse.get("Note"));
        }
        if (dailyResponse.containsKey("Information")) {
            throw new RuntimeException("API limit reached: " + dailyResponse.get("Information"));
        }
        if (dailyResponse == null || !dailyResponse.containsKey("Monthly Time Series")) {
            throw new RuntimeException("Invalid API response");
        }

        Map<String, Map<String, String>> response =
                (Map<String, Map<String, String>>) dailyResponse.get("Monthly Time Series");

//        List<TimeSeriesData> result = new ArrayList<>();

        //EXTARCTING EACH DATE STOCK VALUES AND STORING IN DB
        for (Map.Entry<String, Map<String, String>> entry : response.entrySet()) {

            LocalDate date = LocalDate.parse(entry.getKey());
            Map<String, String> values = entry.getValue();
            if(repository.findByStockAndDateAndIntervalType(
                    stock, date, "MONTHLY").isPresent()) {
                continue;
            }
            TimeSeriesData data = new TimeSeriesData();
            data.setStock(stock);
            data.setDate(date);
            data.setOpen(new BigDecimal(values.get("1. open")));
            data.setHigh(new BigDecimal(values.get("2. high")));
            data.setLow(new BigDecimal(values.get("3. low")));
            data.setClose(new BigDecimal(values.get("4. close")));
            data.setVolume(Long.parseLong(values.get("5. volume")));
            data.setIntervalType("MONTHLY");
            repository.save(data);

            //result.add(data);
        }
        //result.sort(Comparator.comparing(TimeSeriesData::getDate));
        return true;
    }

    private void checkApiLimit(String response){
        if(response.contains("Thnak you for using Alpha Vantage")){
            throw new RuntimeException("API limit reached");
        }
    }
}
