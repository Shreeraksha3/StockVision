package com.stock.config;

import com.stock.dto.wrapper.TradingDateUtil;
import com.stock.entity.Stock;
import com.stock.processor.BatchItemProcessor;
import com.stock.reader.BatchItemReader;
import com.stock.repository.StockRepository;
import com.stock.writer.BatchItemWriter;
import lombok.RequiredArgsConstructor;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.StepScope;
import org.springframework.batch.core.job.builder.JobBuilder;
import org.springframework.batch.core.repository.JobRepository;
import org.springframework.batch.core.step.builder.StepBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.transaction.PlatformTransactionManager;

import java.util.List;

@Configuration
@EnableBatchProcessing
@RequiredArgsConstructor
public class BatchConfig {
    private final JobRepository jobRepository;
    private final PlatformTransactionManager transactionManager;

    private final BatchItemProcessor processor;
    private final BatchItemWriter writer;
    private final StockRepository stockRepository;
    private final TradingDateUtil tradingDateUtil;

    @Bean
    @StepScope
    public BatchItemReader dailyReader(){
        List<Stock> stocks = stockRepository.findStocksToUpdate(tradingDateUtil.getLastTradingDay());
        System.out.println(stocks);
        return new BatchItemReader(stocks);
    }

    @Bean
    @StepScope
    public BatchItemReader weeklyReader(){
        List<Stock> stocks = stockRepository.findWeeklyStocks(tradingDateUtil.getLastFriday());
        System.out.println(stocks);
        return new BatchItemReader(stocks);
    }

    @Bean
    @StepScope
    public BatchItemReader monthlyReader(){
        List<Stock> stocks = stockRepository.findMonthlyStocks(tradingDateUtil.getLastMonthEnd());
        System.out.println(stocks);
        return new BatchItemReader(stocks);
    }

    //DAILY STEP
    @Bean
    public  Step dailyStep(){
//        List<Stock> stocks = stockRepository.findStocksToUpdate(tradingDateUtil.getLastTradingDay());
//        System.out.println(stocks);
        return new StepBuilder("dailyStep",jobRepository)
                .<Stock,Stock>chunk(1,transactionManager)
                .reader(dailyReader())
                .processor(processor)
                .writer(writer)
                .build();
    }

    //WEEKLY STEP
    @Bean
    public Step weeklyStep(){
//        List<Stock> stocks = stockRepository.findWeeklyStocks(tradingDateUtil.getLastTradingDay());
        return new StepBuilder("weeklyStep",jobRepository)
                .<Stock,Stock>chunk(1,transactionManager)
                .reader(weeklyReader())
                .processor(processor)
                .writer(writer)
                .build();
    }

    //MONTHLY STEP
    @Bean
    public Step monthlyStep(){
//        List<Stock> stocks = stockRepository.findmonthlyStocks(tradingDateUtil.getLastTradingDay());
        return new StepBuilder("monthlyStep",jobRepository)
                .<Stock,Stock>chunk(1,transactionManager)
                .reader(monthlyReader())
                .processor(processor)
                .writer(writer)
                .build();
    }

    //JOBS
    @Bean
    public Job dailyJob(){
        return new JobBuilder("dailyJob",jobRepository)
                .start(dailyStep())
                .build();
    }
    @Bean
    public Job weeklyJob(){
        return new JobBuilder("weeklyJob",jobRepository)
                .start(weeklyStep())
                .build();
    }
    @Bean
    public Job monthlyJob(){
        return new JobBuilder("monthlyJob",jobRepository)
                .start(monthlyStep())
                .build();
    }

    //    @Bean
//    public Step stockStep(){
//        return new StepBuilder("stockStep",jobRepository)
//                .<Stock, StockBatchResult>chunk(1,transactionManager)
//                .reader(reader)
//                .processor(processor)
//                .writer(writer)
//                .build();
//    }

//    @Bean
//    public Job stockJob(){
//        return new JobBuilder("stockJob",jobRepository)
//                .start(stockStep())
//                .build();
//    }

}
