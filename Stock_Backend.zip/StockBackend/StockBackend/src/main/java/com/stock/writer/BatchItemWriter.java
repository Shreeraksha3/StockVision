package com.stock.writer;

import com.stock.config.BatchContext;
import com.stock.dto.wrapper.IntervalType;
import com.stock.dto.wrapper.TradingDateUtil;
import com.stock.entity.Stock;
import com.stock.repository.StockRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.batch.core.configuration.annotation.StepScope;
import org.springframework.batch.item.Chunk;
import org.springframework.batch.item.ItemWriter;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.time.LocalDate;

@Component
@StepScope
public class BatchItemWriter implements ItemWriter<Stock> {

    private final TradingDateUtil dateUtil;
    private final StockRepository stockRepository;
    private final BatchContext context;
    private final IntervalType intervalType;
    public BatchItemWriter(TradingDateUtil dateUtil, StockRepository stockRepository, BatchContext context, @Value("#{jobParameters['type']}") String type){
        this.dateUtil=dateUtil;
        this.stockRepository=stockRepository;
        this.context=context;
        this.intervalType = IntervalType.valueOf(type);
    }
    @Override
    public void write(Chunk<? extends Stock> items) throws Exception {
        if(context.isApiLimitReached()){
            return;
        }
        LocalDate today = LocalDate.now();
        for(Stock stock : items){
            switch(intervalType){
                case DAILY -> stock.setDailyUpdatedDate(today);
                case WEEKLY -> stock.setWeeklyUpdatedDate(today);
                case MONTHLY -> stock.setMonthlyUpdatedDate(today);
            }
        }
        stockRepository.saveAll(items);
    }
}
