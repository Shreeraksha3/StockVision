package com.stock.repository;

import com.stock.dto.AdminStockView;
import com.stock.dto.StockView;
import com.stock.entity.Stock;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;

@Repository
public interface StockRepository extends JpaRepository<Stock,Long> {

    Stock findBySymbol(String symbol);

    boolean existsBySymbol(String symbol);

    @Query("SELECT s FROM Stock s WHERE s.isActive = true AND (s.dailyUpdatedDate IS NULL OR s.dailyUpdatedDate < :expectedDate)")
    List<Stock> findStocksToUpdate(@Param("expectedDate") LocalDate expectedDate);

    @Query("SELECT s FROM Stock s WHERE s.isActive = true AND (s.weeklyUpdatedDate IS NULL OR s.weeklyUpdatedDate < :expectedDate)")
    List<Stock> findWeeklyStocks(@Param("expectedDate") LocalDate expectedDate);

    @Query("SELECT s FROM Stock s WHERE s.isActive = true AND (s.monthlyUpdatedDate IS NULL OR s.monthlyUpdatedDate < :expectedDate)")
    List<Stock> findMonthlyStocks(@Param("expectedDate") LocalDate expectedDate);

    @Query("""
            SELECT
                s.symbol AS symbol,
                s.cmpName AS cmpName,
                t.close AS closePrice,
                (t.close - t.open) AS price,
                ROUND(((t.close - t.open) / NULLIF(t.open,0))*100,2) AS percentage,
                CASE
                    WHEN t.close > t.open THEN 'GAIN'
                    WHEN t.close < t.open THEN 'LOSS'
                    ELSE 'NO_CHANGE'
                END AS status
            FROM Stock s
            JOIN TimeSeriesData t ON t.stock = s
            WHERE s.isActive=true AND t.intervalType = 'DAILY' AND t.date = (
               SELECT MAX(t2.date)
               FROM TimeSeriesData t2
               WHERE t2.intervalType = 'DAILY' AND t2.stock = s
            )
            ORDER BY ((t.close - t.open) / NULLIF(t.open,0)) DESC
            """)
    List<StockView> findAllStockWithLatestData();

    List<AdminStockView> findAllBy();
}
