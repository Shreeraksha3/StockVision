package com.stock.controller;

import com.stock.dto.AuthResponse;
import com.stock.entity.User;
import com.stock.service.AuthService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/auth")
@RequiredArgsConstructor
@CrossOrigin(origins = "*")
public class AuthController {

    private final AuthService authService;

    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody Map<String,String> req){
        try{
            String username = req.get("username");
            String password = req.get("password");
            String token =  authService.login(username,password);
            String role = authService.getUserRole(username);
            return ResponseEntity.ok(new AuthResponse(token,username,role));
        }catch(UsernameNotFoundException | BadCredentialsException e){
            return ResponseEntity.badRequest().body(
                    Map.of("error",e.getMessage())
            );
        }
    }

    @PostMapping("/register")
    public ResponseEntity<?> register(@RequestBody Map<String,String> req){
        try{
            User user =  authService.register(req.get("username"),req.get("password"));
            return ResponseEntity.ok(
                    Map.of(
                            "message","User Registered Successfully",
                            "username", user.getUsername(),
                            "role",user.getRole().name()
                    )
            );
        }
        catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().body(
                    Map.of("error", e.getMessage())
            );
        }
    }
}
