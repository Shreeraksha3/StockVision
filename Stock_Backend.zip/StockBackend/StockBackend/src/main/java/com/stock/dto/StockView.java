package com.stock.dto;

import java.math.BigDecimal;

public interface StockView {
    String getSymbol();
    String getCmpName();
    BigDecimal getClosePrice();
    Double getPrice();
    Double getPercentage();
    String getStatus();
}
