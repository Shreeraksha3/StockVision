package com.stock.entity;

import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDate;

@Getter
@Setter
@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "Stock")
public class Stock {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String symbol;

    private String cmpName;

    @Column(length = 5000)
    private String description;

    @Column(name = "is_active", nullable = false)
    private boolean isActive = true;

    private LocalDate dailyUpdatedDate;
    private LocalDate weeklyUpdatedDate;
    private LocalDate monthlyUpdatedDate;


}
