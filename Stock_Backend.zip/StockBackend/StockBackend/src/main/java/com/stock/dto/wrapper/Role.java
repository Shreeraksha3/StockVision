package com.stock.dto.wrapper;

public enum Role {
    USER,
    ADMIN
}
