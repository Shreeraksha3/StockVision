package com.stock.service;

import com.stock.dto.AdminStockView;
import com.stock.dto.StockView;
import com.stock.entity.Stock;
import com.stock.repository.StockRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class AdminService {

    private final StockRepository stockRepository;

    // Returns all the stock details stored in Stock table as StockView DTO template to frontend
    public List<AdminStockView> getAllStockList(){
        return stockRepository.findAllBy();
    }

    public Stock updateStockStatus(String symbol, boolean status){
        Stock stock = stockRepository.findBySymbol(symbol);
        stock.setActive(status);
        return stockRepository.save(stock);
    }

}
