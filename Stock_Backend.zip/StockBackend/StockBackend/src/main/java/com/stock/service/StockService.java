package com.stock.service;

import com.stock.dto.StockView;
import com.stock.entity.Stock;
import com.stock.entity.TimeSeriesData;
import com.stock.repository.StockRepository;
import com.stock.repository.TimeSeriesDataRepository;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.math.BigDecimal;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.List;
import java.util.Map;
import java.util.Optional;

@Service
@Transactional
public class StockService {

    @Autowired
    private StockRepository stockRepository;

    @Autowired
    private TimeSeriesDataRepository timeSeriesDataRepository;

    @Value("${ALPHAVANTAGE_APIKEY}")
    private String apiKey;

    @Value("${ALPHAVANTAGE_BASEURL}")
    private String baseUrl;

    @Autowired
    private RestTemplate restTemplate;

    //It will add Stock Overview details to Stock table
    public Stock saveStockOverview(String symbol){
        String overviewUrl = baseUrl + "?function=OVERVIEW&symbol=" + symbol + "&apikey=" + apiKey;
        //System.out.println(overviewUrl);
        Map<String, String> overview;
        try{
            overview = restTemplate.getForObject(overviewUrl, Map.class);
            System.out.println(overview);
            Thread.sleep(10000);
        }catch(Exception e){
            System.out.println("API CALL FAILED : "+e.getMessage());
            throw new RuntimeException("External API Error");
        }

        if (overview == null || overview.isEmpty()) {
            throw new RuntimeException("Stock overview not found for " + symbol);
        }

        Stock stock = new Stock();
        stock.setSymbol(symbol);
        stock.setCmpName(overview.get("Name"));
        stock.setDescription(overview.get("Description"));
        return stockRepository.save(stock);
    }

    // It is used to add stock data to DB as Daily/Weekly/Monthly based on request.
    // First it will check whether Stock table has overview details for that Symbol.
    // If overview details are not there first will call saveStockOverview method and update Stock table with that details.
    // Then call Daily/Weekly/Monthly data of that Symbol and stores in TimeSeriesData table.
    public boolean saveStockData(String symbol, String intervalType) {

        //CHECKING WHETHER THE STOCK DETAILS PRESENT IN STOCK DB OR NOT
        if (!stockRepository.existsBySymbol(symbol)) {
            saveStockOverview(symbol);
        }

        //SETTING URL AND CALLING API
        String dailyUrl = baseUrl + "?function=TIME_SERIES_"+intervalType+"&symbol=" + symbol + "&apikey=" + apiKey;
        //System.out.println(dailyUrl);
        Map<String, Object> dailyResponse;
        try{
            dailyResponse = restTemplate.getForObject(dailyUrl, Map.class);
            //System.out.println(dailyResponse);

        }catch(Exception e){
            System.out.println("API CALL FAILED : "+e.getMessage());
            throw new RuntimeException("External API Error");
        }

        String intervalFlag = "Time Series (Daily)";

        if(intervalType.equals("WEEKLY")){
            intervalFlag = "Weekly Time Series";
        }else if(intervalType.equals("MONTHLY")){
            intervalFlag = "Monthly Time Series";
        }


        if (dailyResponse == null || !dailyResponse.containsKey(intervalFlag)) {
            throw new RuntimeException("Invalid API response");
        }

        Stock stock = stockRepository.findBySymbol(symbol);


        //SETTING KEYS FOR DAILY WEEEKLY AND MONTHLY REQUEST
        Map<String, Map<String, String>> response =
                (Map<String, Map<String, String>>) dailyResponse.get(intervalFlag);


        //EXTARCTING EACH DATE STOCK VALUES AND STORING IN DB
        for (Map.Entry<String, Map<String, String>> entry : response.entrySet()) {

            LocalDate date = LocalDate.parse(entry.getKey());
            Map<String, String> values = entry.getValue();

            if(timeSeriesDataRepository.findByStockAndDateAndIntervalType(
                    stock, date, intervalType).isPresent()) {
                continue;
            }

            TimeSeriesData data = new TimeSeriesData();

            data.setStock(stock);
            data.setDate(date);
            data.setIntervalType(intervalType);
            data.setOpen(new BigDecimal(values.get("1. open")));
            data.setHigh(new BigDecimal(values.get("2. high")));
            data.setLow(new BigDecimal(values.get("3. low")));
            data.setClose(new BigDecimal(values.get("4. close")));
            data.setVolume(Long.parseLong(values.get("5. volume")));

            timeSeriesDataRepository.save(data);

        }
        return true;
    }


    // Returns all the stock details stored in Stock table as StockView DTO template to frontend
    public List<StockView> getAllStockList(){
        return stockRepository.findAllStockWithLatestData();
    }


    // It will check whether DB is up to date for daily and then returns daily stock data of particular symbol.
    // For weekly/monthly it will directly returns stock weekly/monthly data to frontned.
    public List<TimeSeriesData> checkDbHasUpToDateData(String symbol, String intervalType){
//        Stock stock = stockRepository.findBySymbol(symbol);
////        if(stock == null){
////            saveStockData(symbol,intervalType);
////            stock = stockRepository.findBySymbol(symbol);
////        }
//
//        Optional<TimeSeriesData> dbLatestData = timeSeriesDataRepository.findTopByStockAndIntervalTypeOrderByDateDesc(stock,intervalType);
//
//        boolean isUpToDate = false;
//        LocalDate today = LocalDate.now();
//
//        if(dbLatestData.isPresent()){
//            LocalDate latestDate = dbLatestData.get().getDate();
//            System.out.println("Latest DB Date: "+latestDate);
//
//            if(intervalType.equals("DAILY")){
//                if(stock.getDailyUpdatedDate() == today){
//                    isUpToDate=true;
//                }else{
//                    DayOfWeek dayOfWeek = today.getDayOfWeek();
//                    LocalDate lastValidStockDate = today.minusDays(1);
//
//                    if(dayOfWeek == DayOfWeek.SATURDAY){
//                        lastValidStockDate = today.minusDays(1);
//                    }else if(dayOfWeek == DayOfWeek.SUNDAY){
//                        lastValidStockDate = today.minusDays(2);
//                    }else if(dayOfWeek == DayOfWeek.MONDAY){
//                        lastValidStockDate = today.minusDays(3);
//                    }
//
//                    if(!latestDate.isBefore(lastValidStockDate)){
//                        System.out.println("Stock Daily Data is up to date");
//                        isUpToDate = true;
//                    }
//                }
//
//            }else if(intervalType.equals("WEEKLY")){
////                long weeksDiff = ChronoUnit.WEEKS.between(latestDate,today);
////                if(weeksDiff < 1){
////                    System.out.println("Stock Weekly Data is up to date");
////                    isUpToDate = true;
////                }
//                isUpToDate=true;
//            }else if (intervalType.equals("MONTHLY")){
////                long monthsDiff = ChronoUnit.MONTHS.between(latestDate,today);
////                if(monthsDiff < 1){
////                    System.out.println("Stock Monthly Data is up to date");
////                    isUpToDate = true;
////                }
//                isUpToDate=true;
//            }
//        }
//
//        if(!isUpToDate){
//            System.out.println("Stock Data not up to date");
//            saveStockData(symbol,intervalType);
//        }else{
//            System.out.println("Data already up to date");
//        }

        return timeSeriesDataRepository.findByStockSymbolAndIntervalTypeOrderByDateAsc(symbol,intervalType);

    }
}
