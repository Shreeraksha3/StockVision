package com.stock.processor;

import com.stock.config.BatchContext;
import com.stock.dto.wrapper.IntervalType;
import com.stock.entity.Stock;

import com.stock.repository.TimeSeriesDataRepository;
import com.stock.service.BatchService;
import org.springframework.batch.core.configuration.annotation.StepScope;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
@StepScope
public class BatchItemProcessor implements ItemProcessor<Stock, Stock> {

    private final BatchService batchService;
    private final TimeSeriesDataRepository repo;
    private final BatchContext context;
    private final IntervalType intervalType;

    public BatchItemProcessor(BatchService batchService, TimeSeriesDataRepository repo, BatchContext context, @Value("#{jobParameters['type']}") String type){
        this.batchService = batchService;
        this.repo = repo;
        this.context=context;
        this.intervalType = IntervalType.valueOf(type);
    }

    @Override
    public Stock process(Stock stock) throws Exception {
        try{
           boolean updated = false;
           switch(intervalType){
               case DAILY -> updated = batchService.fetchDaily(stock);
               case WEEKLY -> updated = batchService.fetchWeekly(stock);
               case MONTHLY -> updated = batchService.fetchMonthly(stock);
           }
           if(updated){
               context.incrementUpdated();
           }else{
               context.incrementSkipped();
           }
           return stock;
        }catch(RuntimeException e) {
            if (e.getMessage().contains("API limit")) {
                context.apiLimitReached();
            }
            context.incrementSkipped();
            return null;
        }
    }
}
