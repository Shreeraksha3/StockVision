package com.stock.reader;

import com.stock.entity.Stock;
import org.springframework.batch.item.ItemReader;

import java.util.Iterator;
import java.util.List;

public class BatchItemReader implements ItemReader<Stock> {

    private final Iterator<Stock> stockIterator;

    public BatchItemReader(List<Stock> stocks) {
        this.stockIterator = stocks.iterator();
    }

    @Override
    public Stock read() {
        return stockIterator.hasNext() ? stockIterator.next() : null;
    }
}




//package com.stock.reader;
//
//import com.stock.entity.Stock;
//import lombok.RequiredArgsConstructor;
//import org.springframework.batch.item.ItemReader;
//import org.springframework.stereotype.Component;
//
//import java.util.Iterator;
//import java.util.List;
//
//@Component
//@RequiredArgsConstructor
//public class BatchItemReader implements ItemReader<Stock> {
//
//    private final Iterator<Stock> stockIterator;
//
//    public BatchItemReader(List<Stock> stocks){
//        this.stockIterator = stocks.iterator();
//    }
//
//    @Override
//    public Stock read(){
//        return stockIterator.hasNext() ? stockIterator.next() : null;
//    }
//
//
//
////    private final StockRepository stockRepository;
////    private Iterator<Stock> stockIterator;
////
////    @Override
////    public Stock read() throws Exception, UnexpectedInputException, ParseException, NonTransientResourceException {
////        if(stockIterator == null){
////            LocalDate expectedDate = getLastTradingDay(LocalDate.now());
////            stockIterator = stockRepository.findStocksToUpdate(expectedDate).iterator();
////        }
////        return stockIterator.hasNext() ? stockIterator.next() : null;
////    }
////
////    private LocalDate getLastTradingDay(LocalDate today) {
////        DayOfWeek day = today.getDayOfWeek();
////        if(day == DayOfWeek.SUNDAY) return today.minusDays(1);
////        if(day == DayOfWeek.MONDAY) return today.minusDays(2);
////        return today;
////    }
//
//
//}
