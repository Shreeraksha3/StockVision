package com.stock.dto.wrapper;

public enum IntervalType {
    DAILY,WEEKLY,MONTHLY
}
