package com.stock.dto;

import lombok.*;

@Getter
@Setter
@Data
@AllArgsConstructor
@NoArgsConstructor
public class BatchResult {
    private int updated;
    private int skipped;
    private boolean apiLimitReached;
    private String message;
}
