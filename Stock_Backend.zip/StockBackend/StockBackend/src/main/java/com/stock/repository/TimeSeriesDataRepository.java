package com.stock.repository;

import com.stock.entity.Stock;
import com.stock.entity.TimeSeriesData;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@Repository
public interface TimeSeriesDataRepository extends JpaRepository<TimeSeriesData,Long> {

    List<TimeSeriesData> findByStock(Stock stock);

//    List<TimeSeriesData> findByStockAndDateBetween(Stock stock, LocalDate startDate, LocalDate endDate);

    Optional<TimeSeriesData> findByStockAndDateAndIntervalType(
            Stock stock, LocalDate date, String intervalType
    );

    boolean existsByStockAndDateAndIntervalType(
            Stock stock, LocalDate date, String intervalType
    );

    @Query("SELECT MAX(t.date) FROM TimeSeriesData t WHERE t.stock.id = :stockId AND t.intervalType = :type")
    LocalDate findMaxDate(Long stockId, String type);

    Optional<TimeSeriesData> findTopByStockAndIntervalTypeOrderByDateDesc(Stock stock, String intervalType);

    List<TimeSeriesData> findByStockSymbolAndIntervalTypeOrderByDateAsc(String symbol, String intervalType);

}
