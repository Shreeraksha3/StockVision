package com.stock.repository;

import com.stock.dto.StockView;
import com.stock.entity.Watchlist;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface WatchlistRepository extends JpaRepository<Watchlist,Long> {

    @Query("""
            SELECT
                s.symbol AS symbol,
                s.cmpName AS cmpName,
                t.close AS closePrice,
                (t.close - t.open) AS price,
                ROUND(((t.close - t.open) / NULLIF(t.open,0))*100,2) AS percentage,
                CASE
                    WHEN t.close > t.open THEN 'GAIN'
                    WHEN t.close < t.open THEN 'LOSS'
                    ELSE 'NO_CHANGE'
                END AS status
            FROM Watchlist w
            JOIN w.user u
            JOIN w.stock s
            JOIN TimeSeriesData t ON t.stock = s
            WHERE u.username = :username AND t.intervalType = 'DAILY' AND t.date = (
               SELECT MAX(t2.date)
               FROM TimeSeriesData t2
               WHERE t2.intervalType = 'DAILY' AND t2.stock = s
            )
            ORDER BY ((t.close - t.open) / NULLIF(t.open,0)) DESC
            """)
    List<StockView> getUserWatchlist(@Param("username") String username);

    boolean existsByUserIdAndStockSymbol(Long userId, String symbol);

    Optional<Watchlist> findByUserIdAndStockSymbol(Long userId, String symbol);
}
