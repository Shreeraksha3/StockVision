package com.stock.controller;

import com.stock.dto.AdminStockView;
import com.stock.dto.BatchResult;
import com.stock.entity.Stock;
import com.stock.processor.BatchItemProcessor;
import com.stock.service.AdminService;
import com.stock.service.StockService;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.batch.item.ExecutionContext;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/admin")
@CrossOrigin(origins = "*")
public class AdminController {

    private final JobLauncher jobLauncher;
    private final Job dailyJob;
    private final Job weeklyJob;
    private final Job monthlyJob;
    private final BatchItemProcessor processor;
    private final StockService service;
    private final AdminService adminService;


    public AdminController(
            JobLauncher jobLauncher,
            @Qualifier("dailyJob") Job dailyJob,
            @Qualifier("weeklyJob") Job weeklyJob,
            @Qualifier("monthlyJob") Job monthlyJob,
            BatchItemProcessor processor,
            StockService service,
            AdminService adminService) {

        this.jobLauncher = jobLauncher;
        this.dailyJob = dailyJob;
        this.weeklyJob = weeklyJob;
        this.monthlyJob = monthlyJob;
        this.processor = processor;
        this.service = service;
        this.adminService = adminService;
    }


    @PostMapping("/sync/{type}")
    public BatchResult runBatch(@PathVariable String type) throws Exception {
        System.out.println("Backend called " + type);
        JobExecution execution;

        if (type.equals("DAILY")) {
            execution = jobLauncher.run(dailyJob, getParams("DAILY"));
        } else if (type.equals("WEEKLY")) {
            execution = jobLauncher.run(weeklyJob, getParams("WEEKLY"));
        } else {
            execution = jobLauncher.run(monthlyJob, getParams("MONTHLY"));
        }


        while (execution.isRunning()) {
            Thread.sleep(100);
        }


        return buildResult(execution);
    }

    private BatchResult buildResult(JobExecution execution) {
        ExecutionContext ctx = execution.getExecutionContext();

        int updated = ctx.getInt("updated", 0);
        int skipped = ctx.getInt("skipped", 0);

        Object value = ctx.get("apiLimitReached");
        boolean apiLimit = value instanceof Boolean && (Boolean) value;

        BatchResult result = new BatchResult();
        result.setUpdated(updated);
        result.setSkipped(skipped);
        result.setApiLimitReached(apiLimit);

        if (apiLimit) {
            result.setMessage("API LIMIT REACHED");
        } else if (updated == 0) {
            result.setMessage("ALL STOCKS ARE ALREADY UP TO DATE");
        } else {
            result.setMessage("STOCKS UPDATED SUCCESSFULLY");
        }

        System.out.println(result);

        return result;
    }


    private JobParameters getParams(String type){
        return new JobParametersBuilder()
                .addString("type",type)
                .addLong("time",System.currentTimeMillis())
                .toJobParameters();
    }

    //returns all the stock details as StockView template which have isActive as true from Stock table
    @GetMapping("/getStockList")
    public List<AdminStockView> getAllStockList(){
        return adminService.getAllStockList();
    }

    @PutMapping("/toggle/{symbol}")
    public ResponseEntity<Stock> updateStockStatus(@PathVariable String symbol, @RequestBody Map<String, Boolean> body){
        boolean status = body.get("enabled");
        Stock updated = adminService.updateStockStatus(symbol,status);
        return ResponseEntity.ok(updated);
    }

    //testing purpose

    // adding stock to db from postman
    // testing purpose
    @PostMapping("/addStocks/{symbol}/{intervalType}")
    public boolean createDailySeriesData(@PathVariable String symbol, @PathVariable String intervalType){
        return service.saveStockData(symbol,intervalType);
    }

    //to add stock overview details
    @PostMapping("/addOverview/{symbol}")
    public Stock createStockOverview(@PathVariable String symbol){
        return service.saveStockOverview(symbol);
    }
}
