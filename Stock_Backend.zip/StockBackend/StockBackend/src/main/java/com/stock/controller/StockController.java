package com.stock.controller;

import com.stock.dto.StockView;
import com.stock.entity.Stock;
import com.stock.entity.TimeSeriesData;
import com.stock.service.StockService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/stocks")
@CrossOrigin(origins = "*")
public class StockController {

    @Autowired
    private StockService service;

    //returns all the stock details as StockView template which have isActive as true from Stock table
    @GetMapping("/getStockList")
    public List<StockView> getAllStockList(){
        return service.getAllStockList();
    }

    //returns chart data according to intervaltype
    @GetMapping("/getChartData/{symbol}/{intervalType}")
    public List<TimeSeriesData> getAllChartData(@PathVariable String symbol, @PathVariable String intervalType){
        return service.checkDbHasUpToDateData(symbol,intervalType);
    }
}
