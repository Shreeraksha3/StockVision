package com.stock.dto;

import java.time.LocalDate;

public interface AdminStockView {
    String getSymbol();
    String getCmpName();
    boolean getIsActive();
    LocalDate getDailyUpdatedDate();
    LocalDate getWeeklyUpdatedDate();
    LocalDate getMonthlyUpdatedDate();
}
